const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (TTEOGBOT, message, query) => {
    let p = db.get(`공지_${message.guild.id}`)

    p.send("TEST")
}

exports.callSign = ['test']
exports.helps = {
    description: 'test\n',
    uses: 'test'
}
