exports.run = async (TTEOGBOT, message, channel, msg) => {
    message.channel.send('떡..? 누워서 먹어보세요!');
}


exports.callSign = ['떡', '떡찬', '누워서떡먹기', 'ttoeg']
exports.helps = {
    description: '제작자...?\n',
    uses: 'ㄸ.....ㅓ..ㄱ?'
}
