# 떡봇의 설명

떡봇은 미야봇(JS버전)에 오픈소스를 바탕으로 명령어를 추가하였으며, 이미지 찾기, 투표, 날씨, 유저정보, 번역 등
여러 유틸리티 시스템을 구축하고 있습니다.

# 떡봇의 설명
떡봇은 미야봇(JS버전)을 바탕으로 만들어져있습니다. 미야봇 바탕에 명령어를 추가하였으며,
편리한 기능 또한 있습니다. 4가지 정도 말하자면, 번역, 날씨, 투표, 이미지 찾기 등등이 있죠!

# 떡봇의 대한 피드백
떡봇에 오류가 발생하거나 문의할게 있으신가요? T_피드백 [할말]로 피드백을 주시면 언제나 환영입니다😊

# 사용한 코드&오픈소스
바탕코드 : [미야봇](https://github.com/CwhiteKJ/Miya)(아카이브됨)
커스텀 클래스(classes/TTEOGBOT.js) : [SeoaBot](https://github.com/seoaapp/SeoaBot)    
index.js(./index.js) : [SeoaBot](https://github.com/seoaapp/SeoaBot)    
도움말(commands/help.js) : [SeoaBot](https://github.com/seoaapp/SeoaBot)     
eval(commands/eval.js) : [Wonderbot](https://github.com/wonderlandpark/wonderbot)
이미지(commands/image.js) : [reconlx](https://www.youtube.com/watch?v=c7d8n5IkPSM)
닉네임&닉초기화(commands/nickname.js, nickreset.js) : [reconlx](https://www.youtube.com/watch?v=YRK7uQl7hsY&t=219s)
서버정보(commands/serverinfo.js) : [terrible dev](https://www.youtube.com/watch?v=A9ESJE_6PDM&t=1027s)
번역(commands/translation.js) : [Choiril Official](https://www.youtube.com/watch?v=b1a1VsD_yfE&t=398s)
유저정보(commands/userinfo.js) : [Worn Off Keys](https://www.youtube.com/watch?v=z7OLT5HXXlQ&t=473s)
투표(commands/vote.js) : [김실리](https://www.youtube.com/watch?v=j_kpM-gNStk)
날씨(commands/weather.js) : [김실리](https://www.youtube.com/watch?v=MylCOm7v0ZY&t=49s)